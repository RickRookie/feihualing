//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    shi3: "诗三百全文",
    keystr: "花",
    res: "四月南风大麦黄",
  },
  //事件处理函数
  go2s: function(e) {
    this.data.keystr = e.detail.value.keystr
    this.data.res = ""

    // 尝试从缓存中取shi300全文 
    if (this.data.shi3.length < 20) {
      var value = wx.getStorageSync('shi300')
      if (value) {
        console.log("get shi300 from storge ok")
        //console.log(value)
        this.data.shi3 = value 
      }
    }
    // 下载“唐诗300首”并缓存
    if (this.data.shi3.length < 20) {
      var that = this
      console.log("shi3 not in storge, try to down")
      wx.request({
        url: 'http://202.194.14.33:33380/files/shi300.txt',
        success(res) {
          console.log("shi300.txt fetch ok and stored")
          //console.log(res.data)
          that.data.shi3 = res.data
          wx.setStorageSync('shi300', res.data)
        }
      })
    }

    // 检查每一行，要含有指定key的行
    var reg = new RegExp(".*" + this.data.keystr + ".*")
    var lines = this.data.shi3.split("\n")
    var cti = 0
    for (var i1 in lines) {
      if (reg.test(lines[i1])) {
        this.data.res += lines[i1] + "\n"
        //console.log(lines[i1])     
        if (++cti > 10) {
          this.data.res += "more omitted\n"
          break;
        }
      }
    }
    // 同步显示
    this.setData({
      res: this.data.res
    })
  },

  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function() {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})